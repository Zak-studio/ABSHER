
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-100 py-4 shadow-sm">
      <div className="container mx-auto px-4 md:px-20 max-w-7xl flex justify-between items-center">
        {/* Left: Saudi & Vision 2030 Logos */}
        <div className="flex items-center gap-6">
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Emblem_of_Saudi_Arabia.svg/512px-Emblem_of_Saudi_Arabia.svg.png" 
            alt="Saudi Emblem" 
            className="h-14 w-auto object-contain"
          />
          <div className="h-10 w-px bg-gray-200"></div>
          <img 
            src="https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Saudi_Vision_2030_logo.svg/1200px-Saudi_Vision_2030_logo.svg.png" 
            alt="Vision 2030" 
            className="h-10 w-auto object-contain"
          />
          <div className="h-10 w-px bg-gray-200"></div>
          <div className="flex flex-col items-center justify-center border rounded p-1 px-3 cursor-pointer hover:bg-gray-50">
            <span className="text-saudi-green text-sm font-bold">ع</span>
            <span className="text-[10px] text-gray-500">العربية</span>
          </div>
        </div>

        {/* Right: Hamburger Menu */}
        <div className="flex items-center">
          <button className="p-2 text-saudi-green">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
