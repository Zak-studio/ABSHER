
import React from 'react';

const Breadcrumbs: React.FC = () => {
  return (
    <nav className="text-sm py-2">
      <ul className="flex flex-wrap text-[#666]">
        <li className="hover:text-saudi-green cursor-pointer">Electronic Services</li>
        <li className="mx-2">/</li>
        <li className="hover:text-saudi-green cursor-pointer">Services</li>
        <li className="mx-2">/</li>
        <li className="hover:text-saudi-green cursor-pointer">Passports</li>
        <li className="mx-2">/</li>
        <li className="font-bold text-black">Personal Information</li>
      </ul>
    </nav>
  );
};

export default Breadcrumbs;
