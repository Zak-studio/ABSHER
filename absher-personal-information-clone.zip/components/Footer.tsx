
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-12 border-t border-gray-200">
      <div className="container mx-auto px-4 md:px-20 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-12">
          {/* Column 1: Social & Accessibility */}
          <div>
            <h3 className="text-gray-700 font-bold mb-4">Social Media</h3>
            <div className="flex gap-3 mb-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer hover:bg-saudi-green hover:text-white transition-colors">
                  <div className="w-4 h-4 bg-gray-400 rounded-sm"></div>
                </div>
              ))}
            </div>
            <h3 className="text-gray-700 font-bold mb-4">Accessibility Tools</h3>
            <div className="flex gap-2">
              <button className="border border-gray-300 rounded px-2 py-1 text-xs hover:bg-gray-50">A-</button>
              <button className="border border-gray-300 rounded px-2 py-1 text-xs hover:bg-gray-50">A+</button>
              <button className="border border-gray-300 rounded px-2 py-1 text-xs hover:bg-gray-50">👁</button>
            </div>
          </div>

          {/* Column 2: Important Links */}
          <div>
            <h3 className="text-gray-700 font-bold mb-4">Important Links</h3>
            <ul className="text-sm text-gray-500 space-y-2">
              <li className="hover:text-saudi-green cursor-pointer">Ministry of Interior Portal</li>
              <li className="hover:text-saudi-green cursor-pointer">National Unified Portal</li>
              <li className="hover:text-saudi-green cursor-pointer">National Strategy for Data & Artificial Intelligence</li>
              <li className="hover:text-saudi-green cursor-pointer">Open Data Platform</li>
              <li className="hover:text-saudi-green cursor-pointer">e-Participation Portal</li>
              <li className="hover:text-saudi-green cursor-pointer">Public Consultation Platform</li>
              <li className="hover:text-saudi-green cursor-pointer">e-Procurement Platform</li>
              <li className="hover:text-saudi-green cursor-pointer">Government Mobile Applications</li>
            </ul>
          </div>

          {/* Column 3: About Absher */}
          <div>
            <h3 className="text-gray-700 font-bold mb-4">About Absher</h3>
            <ul className="text-sm text-gray-500 space-y-2">
              <li className="hover:text-saudi-green cursor-pointer">About Absher</li>
              <li className="hover:text-saudi-green cursor-pointer">Privacy Policy</li>
              <li className="hover:text-saudi-green cursor-pointer">Terms of Use</li>
              <li className="hover:text-saudi-green cursor-pointer">News</li>
              <li className="hover:text-saudi-green cursor-pointer">Service level agreement</li>
              <li className="hover:text-saudi-green cursor-pointer">Accessibility</li>
              <li className="hover:text-saudi-green cursor-pointer">Statistical Data</li>
              <li className="hover:text-saudi-green cursor-pointer">Information security</li>
            </ul>
          </div>

          {/* Column 4: Contact and Support */}
          <div>
            <h3 className="text-gray-700 font-bold mb-4">Contact and support</h3>
            <ul className="text-sm text-gray-500 space-y-2 mb-6">
              <li className="hover:text-saudi-green cursor-pointer">Contact Us</li>
              <li className="hover:text-saudi-green cursor-pointer">Report Corruption (Nazaha)</li>
              <li className="hover:text-saudi-green cursor-pointer">FAQs</li>
              <li className="hover:text-saudi-green cursor-pointer">Service channels</li>
              <li className="hover:text-saudi-green cursor-pointer">National ID Activation Channels</li>
              <li className="hover:text-saudi-green cursor-pointer">Registration and Subscription</li>
            </ul>

            {/* Support Box */}
            <div className="bg-saudi-green text-white rounded-lg p-3 mb-4 text-center">
              <div className="flex justify-center mb-1">
                 <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Emblem_of_Saudi_Arabia.svg/512px-Emblem_of_Saudi_Arabia.svg.png" className="h-8 invert" alt="MOI" />
              </div>
              <div className="text-xl font-bold">920020405</div>
            </div>

            {/* Store Buttons */}
            <div className="space-y-2">
              <div className="bg-black text-white rounded-md p-2 flex items-center gap-2 cursor-pointer h-10 w-full justify-center">
                <span className="text-[10px] leading-tight text-left">Download on the<br/><span className="text-sm font-bold">App Store</span></span>
              </div>
              <div className="bg-black text-white rounded-md p-2 flex items-center gap-2 cursor-pointer h-10 w-full justify-center">
                <span className="text-[10px] leading-tight text-left">GET IT ON<br/><span className="text-sm font-bold">Google Play</span></span>
              </div>
              <div className="bg-black text-white rounded-md p-2 flex items-center gap-2 cursor-pointer h-10 w-full justify-center">
                <span className="text-[10px] leading-tight text-left">Download on<br/><span className="text-sm font-bold">AppGallery</span></span>
              </div>
            </div>
            
            {/* Trust Seal */}
            <div className="mt-4 border rounded p-2 text-center">
              <div className="text-[8px] text-gray-400 mb-1">Registered on</div>
              <div className="flex items-center justify-center gap-2">
                 <img src="https://picsum.photos/id/10/40/20" alt="seal" className="h-6 grayscale opacity-50" />
                 <span className="text-[10px] text-gray-500">هيئة الحكومة الرقمية</span>
              </div>
            </div>
          </div>
        </div>

        {/* Sub-footer */}
        <div className="border-t border-gray-100 py-6 text-center text-[10px] text-gray-400">
          <div className="flex justify-center gap-4 mb-4 text-xs font-medium text-gray-500">
            <span className="hover:text-saudi-green cursor-pointer">Sitemap</span>
            <span className="hover:text-saudi-green cursor-pointer">Calendar</span>
          </div>
          <div className="mb-2">
            Powered by <span className="font-bold text-gray-600">National Information Center</span>
            <img src="https://picsum.photos/id/1/20/20" alt="nic" className="inline-block ml-2 rounded-full grayscale" />
          </div>
          <div>Copyright © 1447AH - 2025G Absher, Kingdom of Saudi Arabia.</div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
