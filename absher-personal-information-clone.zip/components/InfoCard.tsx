
import React from 'react';

const InfoRow: React.FC<{ label: string; value: React.ReactNode; labelWidth?: string }> = ({ label, value, labelWidth = "w-44" }) => (
  <div className="flex mb-3 items-start">
    <div className={`${labelWidth} font-bold text-gray-800 text-sm flex justify-between shrink-0`}>
      <span>{label}</span>
      <span className="mx-1">:</span>
    </div>
    <div className="text-gray-700 text-sm pl-2 flex-grow">{value}</div>
  </div>
);

const DateBadge: React.FC<{ type: 'G' | 'H', date: string }> = ({ type, date }) => (
  <div className="flex items-center gap-2 mb-1">
    <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold ${type === 'G' ? 'bg-[#D6EAF8] text-blue-600' : 'bg-[#D1F2EB] text-green-600'}`}>
      {type}
    </span>
    <span className="text-xs text-gray-700">{date}</span>
  </div>
);

const SectionHeader: React.FC<{ title: string }> = ({ title }) => (
  <div className="border-b border-gray-200 mb-6 pb-2">
    <h2 className="text-saudi-green font-bold text-sm uppercase tracking-wide">
      {title}
    </h2>
  </div>
);

const InfoCard: React.FC = () => {
  return (
    <div className="bg-white border border-gray-100 shadow-sm rounded-sm p-8 flex">
      {/* Decorative Left Border */}
      <div className="w-1.5 bg-saudi-green rounded-l-sm mr-6 shrink-0"></div>
      
      <div className="flex-grow">
        {/* Section 1: Personal Information */}
        <div className="mb-10">
          <SectionHeader title="Personal Information" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12">
            <div>
              <InfoRow label="ID Number" value="2624142440" />
              <InfoRow label="ID Version" value="1" />
              <InfoRow label="Name" value={
                <div className="font-medium">
                  SRINIVASAN<br />
                  NITHYANANTHAM<br />
                  RAMALINGAM
                </div>
              } />
              <InfoRow label="Date of Birth" value={
                <div className="flex gap-4">
                  <DateBadge type="G" date="06/01/1968" />
                  <DateBadge type="H" date="06/10/1387" />
                </div>
              } />
              <InfoRow label="Birth Country" value="India" />
              <InfoRow label="Marital Status" value="MARRIED" />
              <InfoRow label="Nationality" value="India" />
            </div>

            <div>
              <InfoRow label="Occupation" value="Warehouse worker" />
              <InfoRow label="Religion" value="Others" />
              <InfoRow label="Entry Date" value="13/12/2025" />
              <InfoRow label="Entry Place" value="King Khaled International Airport" />
              <InfoRow label="Sponsor Name" value={
                <div className="flex flex-col items-end lg:items-start">
                  <span className="text-right lg:text-left">مؤسسة الضوء</span>
                  <span className="text-right lg:text-left">الساطع</span>
                  <span className="text-right lg:text-left">للمقاولات العامة</span>
                </div>
              } />
              <InfoRow label="Sponsor ID" value="7016407756" />
              <InfoRow label="Is Enrolled" value="Yes" />
            </div>
          </div>
        </div>

        {/* Section 2: Iqama Information */}
        <div className="mb-10">
          <SectionHeader title="Iqama Information" />
          <div className="max-w-2xl">
            <InfoRow label="Issue Date" value="15/12/2025" />
            <InfoRow label="Residency Expiry Date" value={
              <div className="flex gap-4">
                <DateBadge type="G" date="11/06/2026" />
                <DateBadge type="H" date="25/12/1447" />
              </div>
            } />
            <InfoRow label="Issue Place" value="Ministry Electronic Portal" />
          </div>
        </div>

        {/* Section 3: Hajj Information */}
        <div className="mb-10">
          <SectionHeader title="Hajj Information" />
          <div className="max-w-2xl">
            <InfoRow label="Is allowed to Hajj" value=":" />
            <InfoRow label="Last Hajj Year" value="-" />
          </div>
        </div>

        {/* Section 4: Other Information */}
        <div>
          <SectionHeader title="Other Information" />
          <div className="max-w-2xl">
            <InfoRow label="Health Insurance Issue Date" value="-" />
            <InfoRow label="Health Insurance Expiry Date" value="-" />
            <InfoRow label="Status" value="-" />
            <InfoRow label="Travel Status" value="Inside" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfoCard;
